rootProject.name = "GuessNumberApp"
include(":app")
