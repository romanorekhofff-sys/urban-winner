# GuessNumberApp

Проект: простая игра "Угадай число" на Kotlin + Jetpack Compose + Room + MPAndroidChart.

Инструкции по загрузке в GitHub и сборке с помощью GitHub Actions будут отдельно.
