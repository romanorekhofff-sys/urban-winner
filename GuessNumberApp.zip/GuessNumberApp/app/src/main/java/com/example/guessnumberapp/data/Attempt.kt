package com.example.guessnumberapp.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "attempts")
data class Attempt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val guessedNumber: Int,
    val targetNumber: Int,
    val success: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)
