package com.example.guessnumberapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.guessnumberapp.ui.GameScreen
import com.example.guessnumberapp.ui.StatsScreen
import com.example.guessnumberapp.ui.theme.GuessNumberAppTheme
import com.example.guessnumberapp.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GuessNumberAppTheme {
                val nav = rememberNavController()
                Scaffold(topBar = {
                    TopAppBar(title = { Text("Угадай число") })
                }) { padding ->
                    NavHost(navController = nav, startDestination = "game") {
                        composable("game") {
                            GameScreen(viewModel = viewModel, onOpenStats = { nav.navigate("stats") })
                        }
                        composable("stats") {
                            StatsScreen(viewModel = viewModel, onBack = { nav.popBackStack() })
                        }
                    }
                }
            }
        }
    }
}
