package com.example.guessnumberapp.ui

import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.guessnumberapp.viewmodel.GameViewModel
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry

@Composable
fun StatsScreen(viewModel: GameViewModel, onBack: () -> Unit) {
    val attempts by viewModel.attempts.collectAsState()
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row {
            Button(onClick = onBack) { Text("Назад") }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text("Всего попыток: ${attempts.size}")
        val successCount = attempts.count { it.success }
        Text("Угадано: $successCount")
        Spacer(modifier = Modifier.height(12.dp))

        AndroidView(factory = { ctx ->
            BarChart(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 600)
                description.isEnabled = false
                xAxis.position = XAxis.XAxisPosition.BOTTOM
                legend.isEnabled = false
            }
        }, update = { chart ->
            val bins = IntArray(10)
            for (a in attempts) {
                val idx = ((a.guessedNumber - 1) / 10).coerceIn(0,9)
                bins[idx] = bins[idx] + if (a.success) 1 else 0
            }
            val entries = mutableListOf<BarEntry>()
            for (i in 0 until 10) entries.add(BarEntry(i.toFloat(), bins[i].toFloat()))
            val set = BarDataSet(entries, "Success per bin")
            set.valueTextSize = 12f
            val data = BarData(set)
            data.barWidth = 0.9f
            chart.data = data
            chart.invalidate()
        })

        Spacer(modifier = Modifier.height(12.dp))

        AndroidView(factory = { ctx ->
            BarChart(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 400)
                description.isEnabled = false
                xAxis.position = XAxis.XAxisPosition.BOTTOM
                legend.isEnabled = false
            }
        }, update = { chart ->
            val success = attempts.count { it.success }
            val fail = attempts.size - success
            val entries = listOf(BarEntry(0f, success.toFloat()), BarEntry(1f, fail.toFloat()))
            val set = BarDataSet(entries, "Success vs Fail")
            set.valueTextSize = 12f
            val data = BarData(set)
            data.barWidth = 0.5f
            chart.data = data
            chart.xAxis.valueFormatter = com.github.mikephil.charting.formatter.IndexAxisValueFormatter(listOf("Успех","Провал"))
            chart.invalidate()
        })
    }
}
