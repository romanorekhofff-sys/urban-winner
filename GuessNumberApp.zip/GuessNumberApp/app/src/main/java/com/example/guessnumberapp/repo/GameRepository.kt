package com.example.guessnumberapp.repo

import android.content.Context
import com.example.guessnumberapp.data.AppDatabase
import com.example.guessnumberapp.data.Attempt

class GameRepository(context: Context) {
    private val dao = AppDatabase.getInstance(context).attemptDao()

    suspend fun insertAttempt(attempt: Attempt) = dao.insert(attempt)

    suspend fun getAllAttempts(): List<Attempt> = dao.getAll()

    suspend fun countSuccess(): Int = dao.countSuccess()

    suspend fun countAll(): Int = dao.countAll()
}
