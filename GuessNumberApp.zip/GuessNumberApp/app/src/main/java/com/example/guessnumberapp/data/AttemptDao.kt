package com.example.guessnumberapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface AttemptDao {
    @Insert
    suspend fun insert(attempt: Attempt)

    @Query("SELECT * FROM attempts ORDER BY timestamp DESC")
    suspend fun getAll(): List<Attempt>

    @Query("SELECT COUNT(*) FROM attempts WHERE success = 1")
    suspend fun countSuccess(): Int

    @Query("SELECT COUNT(*) FROM attempts")
    suspend fun countAll(): Int
}
