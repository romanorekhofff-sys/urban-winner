package com.example.guessnumberapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.guessnumberapp.viewmodel.GameViewModel
import kotlinx.coroutines.launch

@Composable
fun GameScreen(viewModel: GameViewModel, onOpenStats: () -> Unit) {
    val message by viewModel.message.collectAsState()
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {
        Text(text = "Угадай число от 1 до 100", style = MaterialTheme.typography.h6)
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = input, onValueChange = { if (it.length <= 3) input = it.filter { ch -> ch.isDigit() } }, label = { Text("Число") })
        Spacer(modifier = Modifier.height(8.dp))
        Row {
            Button(onClick = {
                val n = input.toIntOrNull()
                if (n == null || n !in 1..100) {
                    scope.launch { /* show snackbar? */ }
                } else {
                    viewModel.guess(n)
                    input = ""
                }
            }) { Text("Отправить") }
            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = onOpenStats) { Text("Статистика") }
        }
        Spacer(modifier = Modifier.height(12.dp))
        if (message.isNotEmpty()) {
            Text(message)
            LaunchedEffect(message) { viewModel.clearMessage() }
        }
    }
}
