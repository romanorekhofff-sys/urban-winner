package com.example.guessnumberapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.example.guessnumberapp.repo.GameRepository
import com.example.guessnumberapp.data.Attempt

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = GameRepository(application.applicationContext)

    private var _targetNumber = MutableStateFlow((1..100).random())
    val targetNumber: StateFlow<Int> get() = _targetNumber

    private val _attempts = MutableStateFlow<List<Attempt>>(emptyList())
    val attempts: StateFlow<List<Attempt>> get() = _attempts

    private val _message = MutableStateFlow("")
    val message: StateFlow<String> get() = _message

    init {
        refreshAttempts()
    }

    fun newGame() {
        _targetNumber.value = (1..100).random()
    }

    fun guess(number: Int) {
        val success = number == _targetNumber.value
        val attempt = Attempt(guessedNumber = number, targetNumber = _targetNumber.value, success = success)
        viewModelScope.launch {
            repo.insertAttempt(attempt)
            refreshAttempts()
        }
        if (success) {
            _message.value = "Угадали! Новая игра начата"
            newGame()
        } else {
            _message.value = if (number < _targetNumber.value) "Больше" else "Меньше"
        }
    }

    private fun refreshAttempts() {
        viewModelScope.launch {
            _attempts.value = repo.getAllAttempts()
        }
    }

    fun clearMessage() { _message.value = "" }
}
